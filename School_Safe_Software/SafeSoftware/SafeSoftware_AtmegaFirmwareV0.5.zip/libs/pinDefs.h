//pin defines 
#define POWERCONTROL 	PD7

#define LATCH 			PB0
#define CLOCK 			PB1
#define DATA_OUT		PB2

#define ENCODER_PIN_A 	PD2
#define ENCODER_PIN_B	PD3
#define ENCODER_BUTTON	PD4

#define SERVO_PORT		PORTD
#define SERVO_DDR 		DDRD
#define SERVO_PIN		PD5
