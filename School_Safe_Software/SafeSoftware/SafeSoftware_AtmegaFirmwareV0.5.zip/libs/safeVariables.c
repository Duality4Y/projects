int pin = 8888; //the actuall pin.
int new_pin = 8888; //currently displayed pin.
//keep track of wheter someone is logged in or not.
uint8_t isLoggedIn = false;
